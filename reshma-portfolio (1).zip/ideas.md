# Portfolio Design Direction

## Approach 1 — Editorial Signal
Very brief intro: A warm editorial portfolio that treats data work like a magazine feature: sharp typography, generous margins, annotated details, and a confident paper-and-ink palette. It feels thoughtful, credible, and human rather than overly corporate.
Probability: 0.07

## Approach 2 — Quiet Systems
Very brief intro: A calm, systems-inspired portfolio built around soft mineral tones, precise rules, modular cards, and subtle chart-like motifs. It communicates analytical rigor while remaining approachable for recruiters.
Probability: 0.04

## Approach 3 — Night Lab
Very brief intro: A dark research-lab aesthetic with electric cyan accents, luminous data traces, and a cinematic atmosphere. It positions the portfolio as experimental and technically ambitious.
Probability: 0.02

## Chosen Approach — Editorial Signal

### Design Movement
Contemporary editorial design with Swiss-grid discipline softened by indie magazine warmth.

### Core Principles
1. Make evidence feel legible: every section should quickly communicate what Reshma did, what she knows, and where a recruiter can verify it.
2. Pair confident serif headlines with a clean sans-serif interface so the portfolio feels authored rather than templated.
3. Use asymmetry and margin notes to create a sense of motion through the page without relying on heavy animation.
4. Treat project links, dates, and tools as editorial metadata: visible, scannable, and consistently styled.

### Color Philosophy
The base is a warm ivory, chosen to feel like a printed portfolio rather than a generic white SaaS page. Ink-black typography gives authority, while a signature vermilion-orange brings energy to key actions and data annotations. Muted sage and slate-blue support secondary surfaces and create a measured, analytical atmosphere.

### Layout Paradigm
A long-form editorial canvas with a narrow left rail for section labels and a flexible content column for evidence. The hero is intentionally offset: a large statement on the left, a compact capability index on the right, and a horizontal metadata strip below. Project cards alternate between full-width feature stories and compact rows.

### Signature Elements
- Small orange index marks and underlines that behave like editorial annotations.
- Oversized section numbers set into the left margin.
- A repeating “signal line” motif: thin rules, tiny nodes, and labels that echo data pipelines without becoming decorative noise.

### Interaction Philosophy
Interactions should feel like turning a page: quick, clear, and tactile. Links underline with a warm-orange sweep, cards lift only slightly, and the navigation highlights the reader’s current section without stealing focus.

### Animation
Use short 180–240ms transitions with a crisp ease-out. On first load, the hero metadata and title reveal in a staggered sequence; project cards enter with small vertical translations; hover states use opacity, transform, and underline changes only. Respect reduced-motion preferences and keep all navigation instant.

### Typography System
Display: Fraunces, 600–700, for the name, section headlines, and project titles. Interface: DM Sans, 400–700, for body copy, labels, navigation, and metadata. Use tight display leading, generous body leading, all-caps micro-labels with letter spacing, and italic serif accents for selected descriptors.

### Brand Essence
A data-science portfolio for recruiters who want clear proof of analytical thinking, practical projects, and dependable execution—not just a list of tools.
Personality: analytical, warm, quietly ambitious.

### Brand Voice
Headlines should be direct and specific. CTAs should feel like invitations to inspect the work, never vague promises. Microcopy should be concise, candid, and evidence-led.

Example lines:
- “Turning untidy datasets into decisions people can act on.”
- “Browse the work, follow the signal.”

### Wordmark & Logo
Use a compact “RA” monogram inside an offset square bracket, suggesting a labeled data field or an editorial crop mark. It should work as a small icon in the nav and as a stamp beside the name.

### Signature Brand Color
Signal Vermilion — `#E85D3F`. It is warm enough to feel human and distinct enough to create immediate recognition across links, indices, and calls to action.

## Style Decisions
- Keep the site light, warm, and editorial; avoid default purple gradients, excessive rounded cards, and generic centered hero layouts.
- Use the strongest visual emphasis for the work and experience sections, not decorative illustration.
- Keep all resume claims grounded in the supplied resume content; do not invent metrics, testimonials, or employer outcomes.

## Reference Override

The user-provided site at https://reshmareddy-portfolio.netlify.app/ is the ground-truth visual specification for this portfolio. Fidelity to that reference takes priority over the earlier Editorial Signal exploration. The implementation now follows its light blue and white palette, compact navigation, modern sans-serif typography, rounded recruiter cards, six-project grid, skills grouping, resume panel, and contact tile structure. Resume facts and the direct email/phone actions remain updated to the user’s latest information.
