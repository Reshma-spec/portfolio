# Reference portfolio notes

Source: https://reshmareddy-portfolio.netlify.app/
Title: Reshma Reddy Ambati | Data Science Portfolio

## Visual structure observed
The reference is a light, clean, modern portfolio with a white-to-pale-blue hero background, a slim white top navigation, blue accent color, and dark gray text. Navigation is horizontal with Home, About, Skills, Projects, Resume, and Contact. The page is a single scrolling layout with a centered content width, large hero heading, compact social links, and rounded/card-based sections.

## Reference content hierarchy
Hero: “Data Science | AI/ML”; “Reshma Reddy Ambati”; “Turning Data into Insights and Insights into Impact.”; aspiring data scientist copy; buttons View Projects, Resume, Contact; GitHub, LinkedIn, and email links.

About: B.Tech in Data Science at Malla Reddy College of Engineering and Technology (2024–2028), CGPA 8.10/10.0, interest in analytics, machine learning, artificial intelligence, EDA, feature engineering, model building, and intelligent systems. Stats shown: 8.10 CGPA, 15+ Projects, 3 Internships, 11+ Certifications.

Skills: Programming; Data Science; Visualization; Databases & Tools. Items include Python, SQL, Java (Basic), C++ (Basic), Pandas, NumPy, Scikit-learn, Statistics, EDA, Feature Engineering, ML, Matplotlib, Seaborn, Power BI, Excel, MySQL, Snowflake, GitHub, Jupyter, Google Colab.

Projects: AI Resume Screener, AI Stock Market, Hotel Analytics, MoodNova, SENTINEL-AI, and SORO. Reference includes Unsplash image URLs and GitHub links including https://github.com/Reshma-spec, https://github.com/Reshma-spec/AI-Resume-Screener, https://github.com/Reshma-spec/AI_Stock_Project, https://github.com/Reshma-spec/Hotel-Data-Analytics, https://github.com/Reshma-spec/moodnova, https://github.com/jahhnavvii/SENTINEL-AI, and https://github.com/Reshma-spec/soro.

Experience in reference: KODBUD Data Science Intern, CODSOFT AI/ML Intern, OASIS INFOBYTE Data Science Intern. User’s updated resume should supersede these older entries with GAO Tek Data Mining Intern — August 2026 – Present and the exact supplied bullets.

Resume section: includes education, internships, key projects, skills, certifications, achievements, email, phone, LinkedIn, GitHub, Telangana, India, download PDF, and print.

Contact: LinkedIn https://linkedin.com/in/reshmareddy-ambati, GitHub https://github.com/Reshma-spec, email mailto:reshmareddyambati@gmail.com, phone +91 8332921809, location Telangana, India, Send Message.

Important: Match the reference’s overall light blue/white, rounded-card, modern recruiter portfolio treatment. Keep direct email and phone contact actions. Do not copy unsupported old internship claims into the new resume-based content.
